/*
 * FINAL CODE - Navigation System
 * 1. 5-Second Yaw Correction against Reference.
 * 2. Reference Yaw updates after Waypoint Turns (+87 / -87).
 * 3. Virtual Wall detects only on LEFT side.
 * 4. Blind drive during FORWARD command (except during the 5s correction pulse).
 */

#include <WiFi.h> 
#include <WebServer.h>
#include <TinyGPS++.h> 
#include <Wire.h> 
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_BNO055.h> 
#include <math.h>

// --- INTEGRATION: INCLUDE CONTROLLER ---
#include "controller.h" 

// ==========================================
// 1. COORDINATE SYSTEM & CONSTANTS
// ==========================================
const double REF_LAT = 48.82987;
const double REF_LON = 12.95516;
const double SCALE = 600000.0;

const float COMPASS_OFFSET = 95.0; 
const float DECLINATION = 4.5;

struct Point2D { float x; float y; };

Point2D getXY(double lat, double lon) {
    Point2D p;
    p.x = (float)((lon - REF_LON) * SCALE);
    p.y = (float)((lat - REF_LAT) * SCALE);
    return p;
}

// ==========================================
// 2. PIN DEFINITIONS
// ==========================================
#define SDA_PIN 21
#define SCL_PIN 22
#define GPS_RX_PIN 16 
#define GPS_TX_PIN 17 

#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 32 
#define OLED_RESET -1   
#define SCREEN_ADDRESS 0x3C 

#define TRIG_FRONT 32
#define ECHO_FRONT 25
#define TRIG_LEFT 4
#define ECHO_LEFT 18
#define TRIG_RIGHT 13
#define ECHO_RIGHT 19

const int OBSTACLE_MIN_CM = 30;                  
const int OBSTACLE_MAX_CM = 40;                 

const unsigned long ULTRASONIC_FRONT_STOP_DURATION_MS = 1000; 
const unsigned long ULTRASONIC_FRONT_STEP_DURATION_MS = 1000;    
const unsigned long ULTRASONIC_SIDE_AVOID_DURATION_MS = 1000;  

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire); 
TinyGPSPlus gps; 

// ==========================================
// 3. VIRTUAL WALL & WAYPOINT DATA
// ==========================================
struct WallPoint { double lat; double lon; };
WallPoint wallBoundaryH[] = {
    {48.829972, 12.955175},
    {48.829689, 12.954934},
    {48.829567, 12.954829},
    {48.829549, 12.954878},
    {48.829415, 12.954756}
};
const int NUM_WALL_POINTS_H = 5;

struct Waypoint {
    double latitude; double longitude;
    const char* command; float geofenceMeters; unsigned long durationMs; 
};

const Waypoint waypointsToH[] = { 
    {48.829985, 12.955169, "TURN RIGHT", 5.0,  2500},
    {48.829540, 12.954758, "STOP",           4.0,  10000}, 
    {48.829503, 12.954718, "TURN RIGHT",  3.5,  2500},
    {48.829609, 12.954418, "TURN LEFT", 3.5,  2500},
    {48.829490, 12.954289, "TURN RIGHT", 3.25,  2500}
};
const int NUM_WP_H = sizeof(waypointsToH) / sizeof(waypointsToH[0]);

// ==========================================
// 4. STATE VARIABLES
// ==========================================
int systemMode = 0; // 0: STOP, 1: H
String unifiedMovementCommand = "WAITING..."; 
float currentHeading = 0; 
WebServer server(80);

float lockedHeading = -1000.0; 
bool avoidanceActive = false;
unsigned long avoidanceStartTime = 0;
const unsigned long AVOIDANCE_LOCK_DURATION = 800; 
String lastSafetyCommand = "NONE";

// --- YAW LOGIC VARIABLES ---
float referenceYawH = 0; 
unsigned long lastYawCorrectionTime = 0;
const unsigned long YAW_CORRECTION_INTERVAL = 5000; 
bool isCorrectingDriftH = false;

bool rcPowerState = false;   
bool robotInitialized = false; 
const int DRIVE_SPEED = 28;  

int completedWaypointCountH = 0; 
String gpsNavigationCommandH = "WAITING"; 
bool isTurning90H = false; 
float turnStartingAngleH = 0; 
String wallCommandH = "NONE";

String ultrasonicCommand = "NONE";             
unsigned long ultrasonicCommandStartTime = 0;   
String frontObstacleSequenceState = "NONE"; 

long frontDistCm = 999; 
long leftDistCm = 999;  
long rightDistCm = 999; 

// ==========================================
// 5. GEOMETRY & SENSOR FUNCTIONS
// ==========================================
bool ccw(Point2D a, Point2D b, Point2D c) {
    return (c.y - a.y) * (b.x - a.x) > (b.y - a.y) * (c.x - a.x);
}

bool intersect(Point2D p1, Point2D p2, Point2D p3, Point2D p4) {
    return ccw(p1, p3, p4) != ccw(p2, p3, p4) &&
           ccw(p1, p2, p3) != ccw(p1, p2, p4);
}

long readUltrasonicDistance(int trigPin, int echoPin) {
    long readings[3]; 
    for (int i = 0; i < 3; i++) {
        digitalWrite(trigPin, LOW); delayMicroseconds(2);
        digitalWrite(trigPin, HIGH); delayMicroseconds(10);
        digitalWrite(trigPin, LOW);
        long duration = pulseIn(echoPin, HIGH, 30000); 
        long distance = 999;
        if (duration > 0) distance = duration * 0.034 / 2;
        readings[i] = distance;
        delay(5); 
    }
    if (readings[0] > readings[1]) { long temp = readings[0]; readings[0] = readings[1]; readings[1] = temp; }
    if (readings[1] > readings[2]) { long temp = readings[1]; readings[1] = readings[2]; readings[2] = temp; }
    if (readings[0] > readings[1]) { long temp = readings[0]; readings[0] = readings[1]; readings[1] = temp; }
    return readings[1];
}

void readAllSensors() {
    frontDistCm = readUltrasonicDistance(TRIG_FRONT, ECHO_FRONT);
    leftDistCm = readUltrasonicDistance(TRIG_LEFT, ECHO_LEFT);
    rightDistCm = readUltrasonicDistance(TRIG_RIGHT, ECHO_RIGHT);
}

// ==========================================
// 6. NAVIGATION & OBSTACLE MODULES
// ==========================================
void checkUltrasonicObstacles() {
    if (frontObstacleSequenceState == "STOP_PHASE") {
        if (millis() - ultrasonicCommandStartTime >= ULTRASONIC_FRONT_STOP_DURATION_MS) {
            if (leftDistCm <= OBSTACLE_MAX_CM) ultrasonicCommand = "STEP RIGHT";
            else ultrasonicCommand = "STEP LEFT";
            frontObstacleSequenceState = "STEP_EXEC_PHASE"; 
            ultrasonicCommandStartTime = millis();
        }
        return; 
    }
    if (frontObstacleSequenceState == "STEP_EXEC_PHASE") {
        if (millis() - ultrasonicCommandStartTime >= ULTRASONIC_FRONT_STEP_DURATION_MS) {
            ultrasonicCommand = "NONE";
            frontObstacleSequenceState = "NONE";
        }
        return; 
    }
    if (ultrasonicCommand == "STEP RIGHT" || ultrasonicCommand == "STEP LEFT") {
        if (millis() - ultrasonicCommandStartTime >= ULTRASONIC_SIDE_AVOID_DURATION_MS) ultrasonicCommand = "NONE"; 
        else return;
    }
    bool leftWarning  = (leftDistCm >= OBSTACLE_MIN_CM && leftDistCm <= OBSTACLE_MAX_CM);
    bool rightWarning = (rightDistCm >= OBSTACLE_MIN_CM && rightDistCm <= OBSTACLE_MAX_CM);
    if (frontDistCm >= OBSTACLE_MIN_CM && frontDistCm <= OBSTACLE_MAX_CM) {
        ultrasonicCommand = "STOP";
        frontObstacleSequenceState = "STOP_PHASE";
        ultrasonicCommandStartTime = millis();
    } 
    else if (leftWarning && rightWarning) { ultrasonicCommand = "NONE"; }
    else if (leftWarning) { ultrasonicCommand = "STEP RIGHT"; ultrasonicCommandStartTime = millis(); } 
    else if (rightWarning) { ultrasonicCommand = "STEP LEFT"; ultrasonicCommandStartTime = millis(); }
    else { ultrasonicCommand = "NONE"; }
}

void checkVirtualWallH() {
    if (!gps.location.isValid()) { wallCommandH = "NONE"; return; }
    Point2D cur = getXY(gps.location.lat(), gps.location.lng());
    float projectionDistXY = 13.5; 
    float leftHeading = currentHeading - 90; 
    if (leftHeading < 0) leftHeading += 360;
    double rad = (450 - leftHeading) * M_PI / 180.0;
    Point2D projected;
    projected.x = cur.x + (projectionDistXY * cos(rad));
    projected.y = cur.y + (projectionDistXY * sin(rad));
    bool hit = false;
    for (int i = 0; i < NUM_WALL_POINTS_H - 1; i++) {
        Point2D w1 = getXY(wallBoundaryH[i].lat, wallBoundaryH[i].lon);
        Point2D w2 = getXY(wallBoundaryH[i+1].lat, wallBoundaryH[i+1].lon);
        if (intersect(cur, projected, w1, w2)) { hit = true; break; }
    }
    wallCommandH = (hit) ? "STEP RIGHT" : "NONE";
}

void checkNavigationH() {
    if (gps.hdop.isValid() && gps.hdop.hdop() > 2.5) return;

    // 1. 5-SECOND DRIFT CHECK (Correction Logic)
    // ONLY RUNS IF NOT TURNING
    if (!isTurning90H && gpsNavigationCommandH == "FORWARD" && (millis() - lastYawCorrectionTime >= YAW_CORRECTION_INTERVAL)) {
        float error = referenceYawH - currentHeading;
        if (error < -180) error += 360;
        if (error > 180) error -= 360;

        if (abs(error) > 2.0) {  // CHANGED FROM 6.0 TO 2.0
            isCorrectingDriftH = true;
            gpsNavigationCommandH = (error > 0) ? "TURN RIGHT" : "TURN LEFT";
        } else {
            isCorrectingDriftH = false;
            lastYawCorrectionTime = millis(); 
        }
    }

    if (isCorrectingDriftH) {
        float error = referenceYawH - currentHeading;
        if (error < -180) error += 360;
        if (error > 180) error -= 360;
        if (abs(error) < 1.0) { // CHANGED FROM 3.0 TO 1.0
            isCorrectingDriftH = false;
            gpsNavigationCommandH = "FORWARD";
            lastYawCorrectionTime = millis();
        }
        return; 
    }

    // 2. WAYPOINT TURNING LOGIC
    if (isTurning90H) {
        Waypoint currentWP = waypointsToH[completedWaypointCountH];
        String cmdStr = String(currentWP.command);
        if (cmdStr.indexOf("TURN") != -1) {
            float diff = abs(currentHeading - turnStartingAngleH); 
            if (diff > 180) diff = 360 - diff;
            
            if (diff >= 82.0) { 
                isTurning90H = false;

                // UPDATE REFERENCE YAW BY EXACTLY 87 DEGREES
                if (cmdStr.indexOf("RIGHT") != -1) referenceYawH += 87;
                else if (cmdStr.indexOf("LEFT") != -1) referenceYawH -= 87;
                
                if (referenceYawH >= 360) referenceYawH -= 360;
                if (referenceYawH < 0) referenceYawH += 360;

                completedWaypointCountH++; 
                gpsNavigationCommandH = "FORWARD"; 
                lastYawCorrectionTime = millis(); // RESTART 5s TIMER AFTER TURN COMPLETES
            }
        } else {
            if (millis() - (unsigned long)turnStartingAngleH >= currentWP.durationMs) { 
                isTurning90H = false;
                completedWaypointCountH++; 
                gpsNavigationCommandH = "FORWARD";
                lastYawCorrectionTime = millis(); // RESTART 5s TIMER AFTER STOP COMPLETES
            }
        }
        return; 
    }

    // 3. DISTANCE CHECKING
    if (gps.location.isValid() && completedWaypointCountH < NUM_WP_H) {
        Waypoint target = waypointsToH[completedWaypointCountH];
        Point2D curPos = getXY(gps.location.lat(), gps.location.lng());
        Point2D tarPos = getXY(target.latitude, target.longitude);
        float distUnits = sqrt(pow(tarPos.x - curPos.x, 2) + pow(tarPos.y - curPos.y, 2));
        
        if (distUnits <= (target.geofenceMeters * 5.4)) {
            isTurning90H = true; 
            gpsNavigationCommandH = target.command;
            // Use current reference as start point for physical turn calculation
            if (String(target.command).indexOf("TURN") != -1) turnStartingAngleH = referenceYawH; 
            else turnStartingAngleH = (float)millis(); 
        } else {
            gpsNavigationCommandH = "FORWARD";
        }
    } else if (completedWaypointCountH >= NUM_WP_H) {
         gpsNavigationCommandH = "STOP";
    }
}

// ==========================================
// 7. WEB SERVER & HARDWARE UI
// ==========================================
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body { font-family: sans-serif; text-align: center; background: #111; color: white; }
  .box { border: 2px solid #00E676; padding: 20px; margin: 20px; border-radius: 15px; }
  button { padding: 15px; font-size: 18px; width: 80%; margin: 10px auto; border-radius: 5px; border: none; font-weight: bold; cursor: pointer; display: block; }
  .btn-h { background-color: #2196F3; color: white; }
  .btn-stop { background-color: #f44336; color: white; }
  .btn-rc { background-color: #9C27B0; color: white; }
  .btn-init { background-color: #00E676; color: black; }
  .disabled { background-color: #555 !important; cursor: not-allowed; color: #888; pointer-events: none; }
  canvas { background: #222; border: 2px solid #555; border-radius: 10px; margin-top: 15px; }
</style></head>
<body>
  <h1>ROBOT DOG H-NAV</h1>
  <div class="box">
    <div id="mode-status">STOPPED</div>
    <div id="cmd" style="font-size: 26px; color: #00E676;">WAITING...</div>
    <div style="font-size: 40px;"><span id="ang">0</span>&deg;</div>
  </div>
  <div style="padding: 10px;">
    <button id="btn-rc" class="btn-rc disabled" onclick="toggleRC()">RC POWER</button>
    <button id="btn-init" class="btn-init" onclick="initializeRobot()">INITIALIZE</button>
  </div>
  <button id="btn-h" class="btn-h disabled" onclick="setMode(1)">GO TO H</button>
  <button id="btn-stop" class="btn-stop disabled" onclick="setMode(0)">STOP SYSTEM</button>
  <canvas id="usCanvas" width="300" height="200"></canvas>
  <script>
    function setMode(mode) { fetch('/setMode?val=' + mode); }
    function toggleRC() { fetch('/toggleRC'); }
    function initializeRobot() { document.getElementById('btn-init').innerText = "INITIALIZING..."; fetch('/initialize'); }
    setInterval(() => {
      fetch('/status').then(r => r.json()).then(d => {
        document.getElementById('cmd').innerText = d.command;
        document.getElementById('ang').innerText = Math.round(d.head);
        document.getElementById("mode-status").innerText = (d.mode == 1) ? "NAVIGATING TO H" : "STOPPED";
        const btnRc = document.getElementById('btn-rc');
        const btnInit = document.getElementById('btn-init');
        const btnH = document.getElementById('btn-h');
        const btnStop = document.getElementById('btn-stop');
        if (!d.init) {
            btnRc.classList.add('disabled'); btnH.classList.add('disabled'); btnStop.classList.add('disabled');
            btnInit.classList.remove('disabled'); btnInit.innerText = "INITIALIZE";
        } else {
            btnRc.classList.remove('disabled'); btnRc.innerText = d.rc ? "RC POWER (ON)" : "RC POWER (OFF)";
            if(d.mode == 0) { btnInit.innerText = "RE-INITIALIZE"; btnInit.classList.remove('disabled'); }
            else { btnInit.innerText = "RUNNING..."; btnInit.classList.add('disabled'); }
            if(d.rc) { btnH.classList.remove('disabled'); btnStop.classList.remove('disabled'); }
            else { btnH.classList.add('disabled'); btnStop.classList.add('disabled'); }
        }
      });
    }, 500);
  </script>
</body></html>)rawliteral";

void handleSetMode() {
  if (server.hasArg("val")) {
    systemMode = server.arg("val").toInt();
    if (systemMode == 1) { 
        referenceYawH = currentHeading; 
        lastYawCorrectionTime = millis();
    }
    completedWaypointCountH = 0; isTurning90H = false;
    ultrasonicCommand = "NONE"; isCorrectingDriftH = false;
  }
  server.send(200, "text/plain", "OK");
}

void handleToggleRC() {
    rcPowerState = !rcPowerState;
    if(!rcPowerState) stop();
    RConoffswitch(); 
    server.send(200, "text/plain", "OK");
}

void handleInitialize() {
    server.send(200, "text/plain", "Initializing...");
    initialcheckuproutine();
    robotInitialized = true;
    rcPowerState = true; 
}

void handleStatus() {
  String json = "{\"mode\":" + String(systemMode) + 
                ",\"command\":\"" + unifiedMovementCommand + 
                "\",\"head\":" + String(currentHeading) + 
                ",\"rc\":" + (rcPowerState ? "true" : "false") +
                ",\"init\":" + (robotInitialized ? "true" : "false") +
                ",\"f\":" + String(frontDistCm) + "}";
  server.send(200, "application/json", json);
}

void applyPhysicalMovement() {
    if (!rcPowerState || !robotInitialized) { stop(); return; }
    if (unifiedMovementCommand == "FORWARD") forward(DRIVE_SPEED);
    else if (unifiedMovementCommand == "TURN LEFT") rotateLeft(DRIVE_SPEED);
    else if (unifiedMovementCommand == "TURN RIGHT") rotateRight(DRIVE_SPEED);
    else if (unifiedMovementCommand == "STEP LEFT") stepLeft(DRIVE_SPEED);
    else if (unifiedMovementCommand == "STEP RIGHT") stepRight(DRIVE_SPEED);
    else stop();
}

// ==========================================
// 8. SETUP & LOOP
// ==========================================
void setup() {
    Serial.begin(115200);
    Wire.begin(SDA_PIN, SCL_PIN);
    initExpMod();
    initDAC();
    if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) { for(;;); }
    display.clearDisplay(); display.display();
    if (!bno.begin()) { while(1); }
    bno.setExtCrystalUse(true);
    pinMode(TRIG_FRONT, OUTPUT); pinMode(ECHO_FRONT, INPUT);
    pinMode(TRIG_LEFT, OUTPUT); pinMode(ECHO_LEFT, INPUT);
    pinMode(TRIG_RIGHT, OUTPUT); pinMode(ECHO_RIGHT, INPUT);
    Serial1.begin(9600, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
    WiFi.softAP("ESP32_NAV_DOG", "12345678");
    server.on("/", [](){ server.send(200, "text/html", index_html); });
    server.on("/setMode", handleSetMode);
    server.on("/status", handleStatus);
    server.on("/toggleRC", handleToggleRC);
    server.on("/initialize", handleInitialize);
    server.begin();
}

void loop() {
    server.handleClient();
    while (Serial1.available() > 0) gps.encode(Serial1.read());

    sensors_event_t event;
    bno.getEvent(&event);
    float adjusted = event.orientation.x - COMPASS_OFFSET;
    if (adjusted < 0) adjusted += 360;
    float calc = adjusted + DECLINATION;
    if (calc >= 360) calc -= 360;
    if (calc < 0) calc += 360;
    currentHeading = calc;

    readAllSensors(); 

    if (systemMode == 1) { 
        checkNavigationH(); 
        checkVirtualWallH();
    }
    checkUltrasonicObstacles();

    // ARBITRATOR
    if (ultrasonicCommand != "NONE") {
        unifiedMovementCommand = ultrasonicCommand;
        lastSafetyCommand = ultrasonicCommand;
        avoidanceActive = true;
        avoidanceStartTime = millis();
    } 
    else if (systemMode == 1 && wallCommandH != "NONE") {
        unifiedMovementCommand = wallCommandH;
        lastSafetyCommand = wallCommandH;
        avoidanceActive = true;
        avoidanceStartTime = millis();
    }
    else if (avoidanceActive && (millis() - avoidanceStartTime < AVOIDANCE_LOCK_DURATION)) {
        unifiedMovementCommand = lastSafetyCommand; 
    }
    else {
        avoidanceActive = false; 
        if (systemMode == 1) unifiedMovementCommand = gpsNavigationCommandH;
        else unifiedMovementCommand = "STOPPED";
    }

    applyPhysicalMovement();

    display.clearDisplay();
    display.setTextColor(WHITE);
    display.setCursor(0,0);
    if (systemMode != 0) {
        display.setTextSize(1);
        display.print("H-REF: " + String((int)referenceYawH));
        display.setCursor(70, 0);
        display.print("Y: " + String((int)currentHeading));
        display.setTextSize(2);
        display.setCursor(0, 18); 
        display.print(unifiedMovementCommand); 
    } else {
        display.setTextSize(1);
        display.print(robotInitialized ? (rcPowerState ? "READY" : "RC OFF") : "INITIALIZE");
    }
    display.display();
    delay(10); 
}